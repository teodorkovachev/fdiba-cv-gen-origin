/**
 * 
 */
package org.tu.sofia.fdiba.cvgen.svc;

import java.util.Map;

/**
 * @author Teo
 *
 */
public interface CVGeneratorService {

	Map<String, ?> getCVMap(String userName);
}
