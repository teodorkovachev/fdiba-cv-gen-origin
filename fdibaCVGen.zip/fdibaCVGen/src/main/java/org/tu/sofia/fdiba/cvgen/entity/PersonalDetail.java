/**
 * 
 */
package org.tu.sofia.fdiba.cvgen.entity;

/**
 * @author Teo
 *
 */
public interface PersonalDetail {
	void setUserName(String userName);
}
