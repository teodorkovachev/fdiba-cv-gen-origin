/**
 * 
 */
package org.tu.sofia.fdiba.cvgen.svc;

import org.tu.sofia.fdiba.cvgen.entity.User;

/**
 * @author Teo
 *
 */
public interface UserService {

	void createUser(User user);
}
