/**
 * 
 */
package org.tu.sofia.fdiba.cvgen.servlet3;

import org.springframework.security.web.context.AbstractSecurityWebApplicationInitializer;

/**
 * @author Teo
 *
 */
public class SecurityInitializer extends AbstractSecurityWebApplicationInitializer {
	//Automatically adds spring security filter chain, instead of declaring it in web.xml
}
